package com.example.resumeGenerationSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResumeGenerationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
