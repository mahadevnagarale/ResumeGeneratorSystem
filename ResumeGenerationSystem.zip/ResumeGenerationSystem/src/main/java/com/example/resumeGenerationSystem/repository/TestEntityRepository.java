package com.example.resumeGenerationSystem.repository;


import com.example.resumeGenerationSystem.entity.TestEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TestEntityRepository extends JpaRepository<TestEntity, Long> {
}
