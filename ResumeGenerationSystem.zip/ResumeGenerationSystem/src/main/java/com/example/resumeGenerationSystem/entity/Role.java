package com.example.resumeGenerationSystem.entity;
public enum Role {
    USER, ADMIN;
}

