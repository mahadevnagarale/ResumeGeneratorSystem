package com.example.resumeGenerationSystem.controller;

import com.example.resumeGenerationSystem.entity.TestEntity;
import com.example.resumeGenerationSystem.repository.TestEntityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @Autowired
    private TestEntityRepository repository;

    @GetMapping("/test")
    public String testDatabase() {
        TestEntity testEntity = new TestEntity();
        testEntity.setName("Database Connection Successful");
        repository.save(testEntity);
        return "Database setup is complete!";
    }
}
